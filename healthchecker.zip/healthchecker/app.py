from flask import Flask, render_template, request, redirect, url_for
from prometheus_client import generate_latest, Counter, Gauge, REGISTRY
from threading import Thread
import time
import requests
import schedule
import yaml
import os
from werkzeug.middleware.dispatcher import DispatcherMiddleware
from prometheus_client import make_wsgi_app

app = Flask(__name__)

# Configuration
CONFIG_FILE = 'endpoints.yaml'
PROBE_INTERVAL = 30  # seconds

# Prometheus metrics
healthcheck_status = Gauge('healthcheck_status', 'Healthcheck status (1=up, 0=down)', ['name', 'url'])
healthcheck_response_time = Gauge('healthcheck_response_time_seconds', 'Healthcheck response time in seconds', ['name', 'url'])
healthcheck_errors = Counter('healthcheck_errors_total', 'Total healthcheck errors', ['name', 'url'])

# In-memory storage for endpoints (persists to YAML file)
endpoints = []

def load_endpoints():
    global endpoints
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, 'r') as f:
            endpoints = yaml.safe_load(f) or []
    else:
        endpoints = []

def save_endpoints():
    with open(CONFIG_FILE, 'w') as f:
        yaml.dump(endpoints, f)

def probe_endpoint(endpoint):
    try:
        start_time = time.time()
        url = f"{endpoint['url']}:{endpoint['port']}{endpoint['path']}" if endpoint['port'] else f"{endpoint['url']}{endpoint['path']}"
        response = requests.get(
            url,
            timeout=10,
            headers={'User-Agent': 'Healthcheck-Probe/1.0'}
        )
        response_time = time.time() - start_time
        
        # Check if expected text is in response
        status = 0
        if endpoint.get('expected_text'):
            status = 1 if endpoint['expected_text'].lower() in response.text.lower() else 0
        else:
            status = 1 if response.status_code < 400 else 0
        
        # Update metrics
        healthcheck_status.labels(name=endpoint['name'], url=url).set(status)
        healthcheck_response_time.labels(name=endpoint['name'], url=url).set(response_time)
        
        return {
            'status': 'UP' if status else 'DOWN',
            'response_time': f"{response_time:.3f}s",
            'status_code': response.status_code,
            'last_checked': time.strftime('%Y-%m-%d %H:%M:%S')
        }
    except Exception as e:
        healthcheck_errors.labels(name=endpoint['name'], url=url).inc()
        return {
            'status': 'DOWN',
            'response_time': 'N/A',
            'status_code': 'N/A',
            'last_checked': time.strftime('%Y-%m-%d %H:%M:%S'),
            'error': str(e)
        }

def probe_all_endpoints():
    for endpoint in endpoints:
        result = probe_endpoint(endpoint)
        endpoint.update(result)

def run_scheduler():
    while True:
        schedule.run_pending()
        time.sleep(1)

# Load endpoints on startup
load_endpoints()

# Schedule periodic probing
schedule.every(PROBE_INTERVAL).seconds.do(probe_all_endpoints)

# Start scheduler thread
scheduler_thread = Thread(target=run_scheduler)
scheduler_thread.daemon = True
scheduler_thread.start()

# Add prometheus wsgi middleware to route /metrics requests
app.wsgi_app = DispatcherMiddleware(app.wsgi_app, {
    '/metrics': make_wsgi_app()
})

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        new_endpoint = {
            'name': request.form['name'],
            'url': request.form['url'],
            'port': request.form['port'],
            'path': request.form['path'],
            'expected_text': request.form['expected_text'],
            'docs_link': request.form['docs_link']
        }
        endpoints.append(new_endpoint)
        save_endpoints()
        return redirect(url_for('index'))
    
    # Initial probe if not already done
    if not any('status' in e for e in endpoints):
        probe_all_endpoints()
    
    # Sort endpoints - those with errors first, then by status (DOWN before UP)
    sorted_endpoints = sorted(
        endpoints,
        key=lambda x: (
            0 if x.get('error') else 1,  # Errors first
            0 if x.get('status') == 'DOWN' else 1  # Then DOWN status
        )
    )
    
    return render_template('index.html', endpoints=sorted_endpoints)


@app.route('/delete/<int:index>', methods=['POST'])
def delete_endpoint(index):
    if 0 <= index < len(endpoints):
        endpoints.pop(index)
        save_endpoints()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000)